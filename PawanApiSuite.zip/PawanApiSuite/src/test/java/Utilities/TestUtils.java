package Utilities;

import BasePackage.BaseTest;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.util.Properties;

public class TestUtils extends BaseTest {

    private static Response responseA;
    private static String inputRequestPayloadString;
    private static int codeA;
    private static int codeB;
    private static Properties ConfigPropFile;

    static {
        try {
            ConfigPropFile = readPropertiesFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public TestUtils() throws IOException {
    }

    public static Response retrieveRespPayload(int petId) {
        String uriPOSTPath = ConfigPropFile.getProperty("uriPath");
        responseA = RestAssured.get(uriPOSTPath + petId);
        return responseA;
    }

    public static int retrieveResponseStatusCode(int petId) {
        codeB = retrieveRespPayload(petId).getStatusCode();
        return codeB;
    }

    public static int loggingInPetsSystem() {
        codeA = RestAssured.given()
                .auth().oauth2("special-key")
                .when()
                .get("https://petstore.swagger.io/oauth/authorize")
                .getStatusCode();
        return codeA;
    }

    public static void createPet(int petId, String name) {
        JSONObject inputRequestPayload = new JSONObject();
        inputRequestPayload.put("id", petId);
        inputRequestPayload.put("name", name);
        inputRequestPayload.put("status", "Available");
        JSONArray photoArray = new JSONArray();
        photoArray.put("String");
        inputRequestPayload.put("photoUrls", photoArray);
        inputRequestPayloadString = inputRequestPayload.toString();
        String uriPOSTPath = ConfigPropFile.getProperty("uriPath");
        Response responseA = RestAssured.given().
                contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .body(inputRequestPayloadString)
                .when()
                .post(uriPOSTPath);
    }


}
