package TestScripts;

import BasePackage.BaseTest;
import Utilities.TestUtils;
import com.aventstack.extentreports.Status;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.SpecificationQuerier;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import report.Utility.ExtentTestManager;

import java.io.IOException;
import java.util.Properties;

public class ScriptNo1 extends BaseTest {

    private static String PetNameValue;
    private static int PetIDValueNumber;

    @Test(priority = 1)
    public void PerformLogging() throws IOException, ParseException {
        JSONObject DataJSON = readJsonDataFile();
        PetNameValue = DataJSON.get("petIDName").toString();
        String petIDValue = DataJSON.get("petIDNumber").toString();
        PetIDValueNumber =Integer.parseInt(petIDValue);
        int code = TestUtils.loggingInPetsSystem();
        Assert.assertEquals(code, 200);
    }

    @Test(priority = 2)
    public void createPetAndCheckItsAvailability() {
        TestUtils.createPet(PetIDValueNumber, PetNameValue);
        String payload = TestUtils.retrieveRespPayload(PetIDValueNumber).asString();
        ExtentTestManager.getTest().log(Status.INFO,"Response is : " + payload);
        Assert.assertTrue(payload.contains(PetNameValue));
    }

    @Test(priority = 3)
    public void getPetAndCheckItsValidity() {
        String payload = TestUtils.retrieveRespPayload(PetIDValueNumber).asString();
        ExtentTestManager.getTest().log(Status.INFO,"Response is : " + payload);
        Assert.assertTrue(payload.contains(PetNameValue));
    }

    @Test(priority = 4)
    public void getResponseStatusCode() {
        int code = TestUtils.retrieveResponseStatusCode(PetIDValueNumber);
        Assert.assertEquals(code, 200);
    }

    @AfterClass
    void tearDown() {
        logger.info("--------------Test Execution Ended ------------");
    }

}



