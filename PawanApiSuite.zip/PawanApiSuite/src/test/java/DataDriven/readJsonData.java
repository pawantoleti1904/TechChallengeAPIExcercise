package DataDriven;

import BasePackage.BaseTest;
import io.restassured.specification.QueryableRequestSpecification;
import io.restassured.specification.SpecificationQuerier;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class readJsonData extends BaseTest {

    @BeforeTest
    public JSONObject  readJsonDataFile() throws IOException, ParseException {
        JSONParser jsonParser = new JSONParser();
        FileReader reader = new FileReader(".\\src\\test\\java\\DataDriven\\testdata.json");
        Object obj = jsonParser.parse(reader);
        JSONObject empjsonobj = (JSONObject)obj;
        String firstnameValue = empjsonobj.get("firstName").toString();
        String lastnameValue = empjsonobj.get("lastName").toString();
        System.out.println(firstnameValue);
        System.out.println(lastnameValue);
        return empjsonobj;

    }

    @Test
    void Test1_CheckResponseBody() throws IOException, ParseException {
        logger.info("--------------Checking Response Body ------------");
        /*String ResponsePayload = OutputResponse.getBody().asString();*/
        String ResponsePayload = readJsonDataFile().toString();
        QueryableRequestSpecification queryable = SpecificationQuerier.query(InputHttpRequest);
        logger.info("Request body ==> "+ queryable.getBaseUri());
        logger.info("Response body ==> "+ ResponsePayload);
        Assert.assertNotNull(ResponsePayload);
        /*ExtentTestManager.getTest().log(Status.INFO,"Response Payload is available");
        ExtentTestManager.getTest().log(Status.INFO,"Request1 is : " + queryable.getBaseUri());
        ExtentTestManager.getTest().log(Status.INFO,"Request2 is : " + queryable.getURI());
        ExtentTestManager.getTest().log(Status.INFO,"Request3 is : " + queryable.getMethod());
        ExtentTestManager.getTest().log(Status.INFO,"Request4 is : " + queryable.getHttpClient());
        ExtentTestManager.getTest().log(Status.INFO,"Request5 is : " + queryable.getContentType());
        ExtentTestManager.getTest().log(Status.INFO,"Request6 is : " + queryable.getRequestParams());
        ExtentTestManager.getTest().log(Status.INFO,"Request7 is : " + queryable.getHeaders());
        ExtentTestManager.getTest().log(Status.INFO,"Request8 is : " + queryable.getBasePath());
        ExtentTestManager.getTest().log(Status.INFO,"Request9 is : " + queryable.getQueryParams());
        ExtentTestManager.getTest().log(Status.INFO,"Response is : " + ResponsePayload);*/
    }

    /*public static JSONObject  readJsonDataFile(String JSONFilePathValue) throws IOException, ParseException {
        JSONParser jsonParser = new JSONParser();
        FileReader reader = new FileReader(".\\test\\java\\DataDriven\\testdata.json");
        Object obj = jsonParser.parse(reader);
        JSONObject empjsonobj = (JSONObject)obj;
        String firstnameValue = empjsonobj.get("firstName").toString();
        String lastnameValue = empjsonobj.get("lastName").toString();
        System.out.println(firstnameValue);
        System.out.println(lastnameValue);
        return empjsonobj;

    }*/
}
