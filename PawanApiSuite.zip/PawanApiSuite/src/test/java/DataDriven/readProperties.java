package DataDriven;

import BasePackage.BaseTest;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class readProperties extends BaseTest {

    public Properties readPropertiesFile (String[] args) throws IOException {
        FileReader propReader = new FileReader(".\\src\\test\\java\\DataDriven\\config.properties");
        Properties properties = new Properties();
        properties.load(propReader);
        String userNameValue = properties.getProperty("username");
        return properties;
    }

}
