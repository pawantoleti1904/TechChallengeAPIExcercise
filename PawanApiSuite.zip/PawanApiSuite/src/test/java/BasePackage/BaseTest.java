package BasePackage;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class BaseTest {

    public static RequestSpecification InputHttpRequest;
    public Logger logger;

    @BeforeClass
    public void setup(){
        System.err.close();
        System.setErr(System.out);
        logger=Logger.getLogger("PawanApiSuite");
        PropertyConfigurator.configure("log4j.properties");
        logger.setLevel(Level.DEBUG);
        logger.info("--------------Test Execution Started ------------");

    }

    @BeforeTest
    public JSONObject readJsonDataFile() throws IOException, ParseException {
        JSONParser jsonParser = new JSONParser();
        FileReader reader = new FileReader(".\\src\\test\\java\\DataDriven\\testdata.json");
        Object obj = jsonParser.parse(reader);
        return (JSONObject)obj;

    }

    @BeforeTest
    public static Properties readPropertiesFile() throws IOException {
        FileReader propReader = new FileReader(".\\src\\test\\java\\DataDriven\\config.properties");
        Properties properties = new Properties();
        properties.load(propReader);
        return properties;
    }

}
